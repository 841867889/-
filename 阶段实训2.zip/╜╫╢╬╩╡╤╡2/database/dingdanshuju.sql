SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------

-- ----------------------------

-- Table structure for dingdanshuju

-- ----------------------------

DROP TABLE IF EXISTS `t_admin`;

CREATE TABLE `t_admin` (`id` int(11) NOT NULL AUTO_INCREMENT COMMENT '管理员id',`username` varchar(255) DEFAULT NULL COMMENT '账号',`password` varchar(255) DEFAULT NULL COMMENT '密码',PRIMARY KEY (`id`)

) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员';


-- ----------------------------

DROP TABLE IF EXISTS `t_dingdan`;

CREATE TABLE `t_dingdan` (`id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单id',`bianhao` varchar(255) DEFAULT NULL COMMENT '订单编号',`shangpin` varchar(255) DEFAULT NULL COMMENT '订单商品',`zongjia` varchar(255) DEFAULT NULL COMMENT '商品总价',`peisongfei` varchar(255) DEFAULT NULL COMMENT '配送费',`youhui` varchar(255) DEFAULT NULL COMMENT '会员优惠',`dingdanzongjia` varchar(255) DEFAULT NULL COMMENT '订单总价',`dingdanriqi` varchar(255) DEFAULT NULL COMMENT '订单日期',`qiwangshijiian` varchar(255) DEFAULT NULL COMMENT '订单期望送达时间',`songdadidian` varchar(255) DEFAULT NULL COMMENT '订单送达区域',PRIMARY KEY (`id`)

) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单';
-- ----------------------------

DROP TABLE IF EXISTS `t_dingdan1`;

CREATE TABLE `t_dingdan1` (`id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单id',`bianhao` varchar(255) DEFAULT NULL COMMENT '订单编号',`shangpin` varchar(255) DEFAULT NULL COMMENT '订单商品',`zongjia` varchar(255) DEFAULT NULL COMMENT '商品总价',`peisongfei` varchar(255) DEFAULT NULL COMMENT '配送费',`youhui` varchar(255) DEFAULT NULL COMMENT '会员优惠',`dingdanzongjia` varchar(255) DEFAULT NULL COMMENT '订单总价',`dingdanriqi` varchar(255) DEFAULT NULL COMMENT '订单日期',`qiwangshijiian` varchar(255) DEFAULT NULL COMMENT '订单期望送达时间',`songdadidian` varchar(255) DEFAULT NULL COMMENT '订单送达区域',PRIMARY KEY (`id`)

) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单';

-- ----------------------------
DROP TABLE IF EXISTS `t_dingdan2`;

CREATE TABLE `t_dingdan2` (`id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单id',`bianhao` varchar(255) DEFAULT NULL COMMENT '订单编号',`shangpin` varchar(255) DEFAULT NULL COMMENT '订单商品',`zongjia` varchar(255) DEFAULT NULL COMMENT '商品总价',`peisongfei` varchar(255) DEFAULT NULL COMMENT '配送费',`youhui` varchar(255) DEFAULT NULL COMMENT '会员优惠',`dingdanzongjia` varchar(255) DEFAULT NULL COMMENT '订单总价',`dingdanriqi` varchar(255) DEFAULT NULL COMMENT '订单日期',`qiwangshijiian` varchar(255) DEFAULT NULL COMMENT '订单期望送达时间',`songdadidian` varchar(255) DEFAULT NULL COMMENT '订单送达区域',PRIMARY KEY (`id`)

) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单';

-- ----------------------------

DROP TABLE IF EXISTS `t_dingdan3`;

CREATE TABLE `t_dingdan3` (`id` int(11) NOT NULL AUTO_INCREMENT COMMENT '订单id',`bianhao` varchar(255) DEFAULT NULL COMMENT '订单编号',`shangpin` varchar(255) DEFAULT NULL COMMENT '订单商品',`zongjia` varchar(255) DEFAULT NULL COMMENT '商品总价',`peisongfei` varchar(255) DEFAULT NULL COMMENT '配送费',`youhui` varchar(255) DEFAULT NULL COMMENT '会员优惠',`dingdanzongjia` varchar(255) DEFAULT NULL COMMENT '订单总价',`dingdanriqi` varchar(255) DEFAULT NULL COMMENT '订单日期',`qiwangshijiian` varchar(255) DEFAULT NULL COMMENT '订单期望送达时间',`songdadidian` varchar(255) DEFAULT NULL COMMENT '订单送达区域',PRIMARY KEY (`id`)

) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单';

-- ----------------------------




