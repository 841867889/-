package com.model;

public class Dingdan {

	private Integer id = 0;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	private String bianhao = "";

	public String getBianhao() {
		return bianhao;
	}

	public void setBianhao(String bianhao) {
		this.bianhao = bianhao;
	}

	private String shangpin = "";

	public String getShangpin() {
		return shangpin;
	}

	public void setShangpin(String shangpin) {
		this.shangpin = shangpin;
	}

	private String zongjia = "";

	public String getZongjia() {
		return zongjia;
	}

	public void setZongjia(String zongjia) {
		this.zongjia = zongjia;
	}

	private String peisongfei = "";

	public String getPeisongfei() {
		return peisongfei;
	}

	public void setPeisongfei(String peisongfei) {
		this.peisongfei = peisongfei;
	}

	private String youhui = "";

	public String getYouhui() {
		return youhui;
	}

	public void setYouhui(String youhui) {
		this.youhui = youhui;
	}

	private String dingdanzongjia = "";

	public String getDingdanzongjia() {
		return dingdanzongjia;
	}

	public void setDingdanzongjia(String dingdanzongjia) {
		this.dingdanzongjia = dingdanzongjia;
	}

	private String dingdanriqi = "";

	public String getDingdanriqi() {
		return dingdanriqi;
	}

	public void setDingdanriqi(String dingdanriqi) {
		this.dingdanriqi = dingdanriqi;
	}

	private String qiwangshijiian = "";

	public String getQiwangshijiian() {
		return qiwangshijiian;
	}

	public void setQiwangshijiian(String qiwangshijiian) {
		this.qiwangshijiian = qiwangshijiian;
	}

	private String songdadidian = "";

	public String getSongdadidian() {
		return songdadidian;
	}

	public void setSongdadidian(String songdadidian) {
		this.songdadidian = songdadidian;
	}

}
