package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.connection.ConnectionManager;

public class SuperOpr {
	protected Connection con;
	protected PreparedStatement psmt;
	protected String sql;
	protected int row;
	protected ResultSet rs;

	public SuperOpr() {
		ConnectionManager cm = new ConnectionManager();
		con = cm.getConnection();
	}

}
