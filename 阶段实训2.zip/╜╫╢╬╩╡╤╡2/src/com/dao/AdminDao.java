package com.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import com.model.Admin;

public class AdminDao extends SuperOpr {

	// 编写管理员插入方法
	public boolean insert(Admin admin) {
		// TODO Auto-generated method stub
		// return false;

		sql = "insert into t_admin (username,password) values ('" + admin.getUsername() + "','" + admin.getPassword()
				+ "')";
		System.out.println(sql);
		try {
			psmt = con.prepareStatement(sql);

			row = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return row > 0 ? true : false;
	}

	// 编写管理员根据ID修改对象方法
	public boolean updateById(Admin admin) {
		// TODO Auto-generated method stub
		// return false;

		sql = "UPDATE t_admin SET ";
		if (admin.getUsername() != null && !"null".equals(admin.getUsername()) && !"".equals(admin.getUsername())) {
			sql += " username = '" + admin.getUsername() + "', ";
		}
		if (admin.getPassword() != null && !"null".equals(admin.getPassword()) && !"".equals(admin.getPassword())) {
			sql += " password = '" + admin.getPassword() + "', ";
		}
		sql = sql.substring(0, sql.length() - 2);
		sql += " WHERE id = " + admin.getId() + " ";
		System.out.println(sql);
		try {
			psmt = con.prepareStatement(sql);

			row = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return row > 0 ? true : false;
	}

	// 编写管理员根据ID删除对象方法
	public boolean deleteById(Integer id) {
		// TODO Auto-generated method stub
		// return false;
		sql = "DELETE FROM t_admin WHERE id = " + id;
		System.out.println(sql);
		try {
			psmt = con.prepareStatement(sql);
			row = psmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return row > 0 ? true : false;
	}

	// 编写管理员根据ID查询对象方法
	public Admin selectById(Integer id) {
		// TODO Auto-generated method stub
		sql = "select * from t_admin where id = " + id;
		System.out.println(sql);
		Admin admin = new Admin();

		try {
			psmt = con.prepareStatement(sql);
			rs = psmt.executeQuery();
			while (rs.next()) {

				// 设置Id字段
				admin.setId(rs.getInt("id"));
				// 设置Username字段
				admin.setUsername(rs.getString("username"));
				// 设置Password字段
				admin.setPassword(rs.getString("password"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return admin;
	}

	// 编写管理员根据查询所有数据方法
	public ArrayList<Admin> selectAll() {
		// TODO Auto-generated method stub
		sql = "select * from t_admin ";
		System.out.println(sql);
		ArrayList<Admin> adminall = new ArrayList<Admin>();

		try {
			psmt = con.prepareStatement(sql);
			rs = psmt.executeQuery();
			while (rs.next()) {
				Admin admin = new Admin();

				// 设置Id字段
				admin.setId(rs.getInt("id"));
				// 设置Username字段
				admin.setUsername(rs.getString("username"));
				// 设置Password字段
				admin.setPassword(rs.getString("password"));
				adminall.add(admin);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return adminall;
	}

	// 编写管理员根据传入的参数模糊查询方法
	public ArrayList<Admin> selectByprotyteLike(Admin adminitem) {
		// TODO Auto-generated method stub
		sql = "select * from t_admin where 2 > 1 ";
		if (adminitem.getUsername() != null && !"null".equals(adminitem.getUsername())
				&& !"".equals(adminitem.getUsername())) {
			sql += " and username like '%" + adminitem.getUsername() + "%' ";
		}
		if (adminitem.getPassword() != null && !"null".equals(adminitem.getPassword())
				&& !"".equals(adminitem.getPassword())) {
			sql += " and password like '%" + adminitem.getPassword() + "%' ";
		}
		System.out.println(sql);
		ArrayList<Admin> adminall = new ArrayList<Admin>();

		try {
			psmt = con.prepareStatement(sql);
			rs = psmt.executeQuery();
			while (rs.next()) {
				Admin admin = new Admin();

				// 设置Id字段
				admin.setId(rs.getInt("id"));
				// 设置Username字段
				admin.setUsername(rs.getString("username"));
				// 设置Password字段
				admin.setPassword(rs.getString("password"));
				adminall.add(admin);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return adminall;
	}

	// 编写管理员根据精准匹配查询方法
	public ArrayList<Admin> selectByprotyteEquals(Admin adminitem) {
		// TODO Auto-generated method stub
		sql = "select * from t_admin where 2 > 1 ";
		if (adminitem.getUsername() != null && !"null".equals(adminitem.getUsername())
				&& !"".equals(adminitem.getUsername())) {
			sql += " and username = '" + adminitem.getUsername() + "' ";
		}
		if (adminitem.getPassword() != null && !"null".equals(adminitem.getPassword())
				&& !"".equals(adminitem.getPassword())) {
			sql += " and password = '" + adminitem.getPassword() + "' ";
		}
		System.out.println(sql);
		ArrayList<Admin> adminall = new ArrayList<Admin>();

		try {
			psmt = con.prepareStatement(sql);
			rs = psmt.executeQuery();
			while (rs.next()) {
				Admin admin = new Admin();

				// 设置Id字段
				admin.setId(rs.getInt("id"));
				// 设置Username字段
				admin.setUsername(rs.getString("username"));
				// 设置Password字段
				admin.setPassword(rs.getString("password"));
				adminall.add(admin);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return adminall;
	}

	// 编写管理员根据字段排序查询方法
	public ArrayList<Admin> selectByProtyteOrder(String protyte, String order, Integer num) {
		// TODO Auto-generated method stub
		sql = "select * from t_admin order by " + protyte + " ";

		if (order != null && !"null".equals(order) && !"".equals(order)) {
			sql += order;
		}

		System.out.println(sql);
		ArrayList<Admin> adminall = new ArrayList<Admin>();
		try {
			psmt = con.prepareStatement(sql);
			rs = psmt.executeQuery();
			while (rs.next()) {
				Admin admin = new Admin();

				// 设置Id字段
				admin.setId(rs.getInt("id"));
				// 设置Username字段
				admin.setUsername(rs.getString("username"));
				// 设置Password字段
				admin.setPassword(rs.getString("password"));
				adminall.add(admin);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (num == null || "".equals(num)) {
			adminall = adminall;
		} else {
			if (num <= adminall.size()) {
				adminall = (ArrayList<Admin>) adminall.subList(0, num);
			}
		}

		return adminall;
	}
}
