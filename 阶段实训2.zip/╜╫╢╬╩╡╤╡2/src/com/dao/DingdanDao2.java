package com.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import com.model.Dingdan;

public class DingdanDao2 extends SuperOpr {

    // 编写订单插入方法
    public boolean insert(Dingdan dingdan) {
        // TODO Auto-generated method stub
        // return false;

        sql = "insert into t_dingdan2 (bianhao,shangpin,zongjia,peisongfei,youhui,dingdanzongjia,dingdanriqi,qiwangshijiian,songdadidian) values ('"
                + dingdan.getBianhao() + "','" + dingdan.getShangpin() + "','" + dingdan.getZongjia() + "','"
                + dingdan.getPeisongfei() + "','" + dingdan.getYouhui() + "','" + dingdan.getDingdanzongjia() + "','"
                + dingdan.getDingdanriqi() + "','" + dingdan.getQiwangshijiian() + "','" + dingdan.getSongdadidian()
                + "')";
        System.out.println(sql);
        try {
            psmt = con.prepareStatement(sql);

            row = psmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return row > 0 ? true : false;
    }

    // 编写订单根据ID修改对象方法
    public boolean updateById(Dingdan dingdan) {
        // TODO Auto-generated method stub
        // return false;

        sql = "UPDATE t_dingdan2 SET ";
        if (dingdan.getBianhao() != null && !"null".equals(dingdan.getBianhao()) && !"".equals(dingdan.getBianhao())) {
            sql += " bianhao = '" + dingdan.getBianhao() + "', ";
        }
        if (dingdan.getShangpin() != null && !"null".equals(dingdan.getShangpin())
                && !"".equals(dingdan.getShangpin())) {
            sql += " shangpin = '" + dingdan.getShangpin() + "', ";
        }
        if (dingdan.getZongjia() != null && !"null".equals(dingdan.getZongjia()) && !"".equals(dingdan.getZongjia())) {
            sql += " zongjia = '" + dingdan.getZongjia() + "', ";
        }
        if (dingdan.getPeisongfei() != null && !"null".equals(dingdan.getPeisongfei())
                && !"".equals(dingdan.getPeisongfei())) {
            sql += " peisongfei = '" + dingdan.getPeisongfei() + "', ";
        }
        if (dingdan.getYouhui() != null && !"null".equals(dingdan.getYouhui()) && !"".equals(dingdan.getYouhui())) {
            sql += " youhui = '" + dingdan.getYouhui() + "', ";
        }
        if (dingdan.getDingdanzongjia() != null && !"null".equals(dingdan.getDingdanzongjia())
                && !"".equals(dingdan.getDingdanzongjia())) {
            sql += " dingdanzongjia = '" + dingdan.getDingdanzongjia() + "', ";
        }
        if (dingdan.getDingdanriqi() != null && !"null".equals(dingdan.getDingdanriqi())
                && !"".equals(dingdan.getDingdanriqi())) {
            sql += " dingdanriqi = '" + dingdan.getDingdanriqi() + "', ";
        }
        if (dingdan.getQiwangshijiian() != null && !"null".equals(dingdan.getQiwangshijiian())
                && !"".equals(dingdan.getQiwangshijiian())) {
            sql += " qiwangshijiian = '" + dingdan.getQiwangshijiian() + "', ";
        }
        if (dingdan.getSongdadidian() != null && !"null".equals(dingdan.getSongdadidian())
                && !"".equals(dingdan.getSongdadidian())) {
            sql += " songdadidian = '" + dingdan.getSongdadidian() + "', ";
        }
        sql = sql.substring(0, sql.length() - 2);
        sql += " WHERE id = " + dingdan.getId() + " ";
        System.out.println(sql);
        try {
            psmt = con.prepareStatement(sql);

            row = psmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return row > 0 ? true : false;
    }

    // 编写订单根据ID删除对象方法
    public boolean deleteById(Integer id) {
        // TODO Auto-generated method stub
        // return false;
        sql = "DELETE FROM t_dingdan2 WHERE id = " + id;
        System.out.println(sql);
        try {
            psmt = con.prepareStatement(sql);
            row = psmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return row > 0 ? true : false;
    }

    // 编写订单根据ID查询对象方法
    public Dingdan selectById(Integer id) {
        // TODO Auto-generated method stub
        sql = "select * from t_dingdan2 where id = " + id;
        System.out.println(sql);
        Dingdan dingdan = new Dingdan();

        try {
            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery();
            while (rs.next()) {

                // 设置Id字段
                dingdan.setId(rs.getInt("id"));
                // 设置Bianhao字段
                dingdan.setBianhao(rs.getString("bianhao"));
                // 设置Shangpin字段
                dingdan.setShangpin(rs.getString("shangpin"));
                // 设置Zongjia字段
                dingdan.setZongjia(rs.getString("zongjia"));
                // 设置Peisongfei字段
                dingdan.setPeisongfei(rs.getString("peisongfei"));
                // 设置Youhui字段
                dingdan.setYouhui(rs.getString("youhui"));
                // 设置Dingdanzongjia字段
                dingdan.setDingdanzongjia(rs.getString("dingdanzongjia"));
                // 设置Dingdanriqi字段
                dingdan.setDingdanriqi(rs.getString("dingdanriqi"));
                // 设置Qiwangshijiian字段
                dingdan.setQiwangshijiian(rs.getString("qiwangshijiian"));
                // 设置Songdadidian字段
                dingdan.setSongdadidian(rs.getString("songdadidian"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dingdan;
    }

    // 编写订单根据查询所有数据方法
    public ArrayList<Dingdan> selectAll() {
        // TODO Auto-generated method stub
        sql = "select * from t_dingdan2 ";
        System.out.println(sql);
        ArrayList<Dingdan> dingdanall = new ArrayList<Dingdan>();

        try {
            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery();
            while (rs.next()) {
                Dingdan dingdan = new Dingdan();

                // 设置Id字段
                dingdan.setId(rs.getInt("id"));
                // 设置Bianhao字段
                dingdan.setBianhao(rs.getString("bianhao"));
                // 设置Shangpin字段
                dingdan.setShangpin(rs.getString("shangpin"));
                // 设置Zongjia字段
                dingdan.setZongjia(rs.getString("zongjia"));
                // 设置Peisongfei字段
                dingdan.setPeisongfei(rs.getString("peisongfei"));
                // 设置Youhui字段
                dingdan.setYouhui(rs.getString("youhui"));
                // 设置Dingdanzongjia字段
                dingdan.setDingdanzongjia(rs.getString("dingdanzongjia"));
                // 设置Dingdanriqi字段
                dingdan.setDingdanriqi(rs.getString("dingdanriqi"));
                // 设置Qiwangshijiian字段
                dingdan.setQiwangshijiian(rs.getString("qiwangshijiian"));
                // 设置Songdadidian字段
                dingdan.setSongdadidian(rs.getString("songdadidian"));
                dingdanall.add(dingdan);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dingdanall;
    }

    // 编写订单根据传入的参数模糊查询方法
    public ArrayList<Dingdan> selectByprotyteLike(Dingdan dingdanitem) {
        // TODO Auto-generated method stub
        sql = "select * from t_dingdan2 where 2 > 1 ";
        if (dingdanitem.getBianhao() != null && !"null".equals(dingdanitem.getBianhao())
                && !"".equals(dingdanitem.getBianhao())) {
            sql += " and bianhao like '%" + dingdanitem.getBianhao() + "%' ";
        }
        if (dingdanitem.getShangpin() != null && !"null".equals(dingdanitem.getShangpin())
                && !"".equals(dingdanitem.getShangpin())) {
            sql += " and shangpin like '%" + dingdanitem.getShangpin() + "%' ";
        }
        if (dingdanitem.getZongjia() != null && !"null".equals(dingdanitem.getZongjia())
                && !"".equals(dingdanitem.getZongjia())) {
            sql += " and zongjia like '%" + dingdanitem.getZongjia() + "%' ";
        }
        if (dingdanitem.getPeisongfei() != null && !"null".equals(dingdanitem.getPeisongfei())
                && !"".equals(dingdanitem.getPeisongfei())) {
            sql += " and peisongfei like '%" + dingdanitem.getPeisongfei() + "%' ";
        }
        if (dingdanitem.getYouhui() != null && !"null".equals(dingdanitem.getYouhui())
                && !"".equals(dingdanitem.getYouhui())) {
            sql += " and youhui like '%" + dingdanitem.getYouhui() + "%' ";
        }
        if (dingdanitem.getDingdanzongjia() != null && !"null".equals(dingdanitem.getDingdanzongjia())
                && !"".equals(dingdanitem.getDingdanzongjia())) {
            sql += " and dingdanzongjia like '%" + dingdanitem.getDingdanzongjia() + "%' ";
        }
        if (dingdanitem.getDingdanriqi() != null && !"null".equals(dingdanitem.getDingdanriqi())
                && !"".equals(dingdanitem.getDingdanriqi())) {
            sql += " and dingdanriqi like '%" + dingdanitem.getDingdanriqi() + "%' ";
        }
        if (dingdanitem.getQiwangshijiian() != null && !"null".equals(dingdanitem.getQiwangshijiian())
                && !"".equals(dingdanitem.getQiwangshijiian())) {
            sql += " and qiwangshijiian like '%" + dingdanitem.getQiwangshijiian() + "%' ";
        }
        if (dingdanitem.getSongdadidian() != null && !"null".equals(dingdanitem.getSongdadidian())
                && !"".equals(dingdanitem.getSongdadidian())) {
            sql += " and songdadidian like '%" + dingdanitem.getSongdadidian() + "%' ";
        }
        System.out.println(sql);
        ArrayList<Dingdan> dingdanall = new ArrayList<Dingdan>();

        try {
            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery();
            while (rs.next()) {
                Dingdan dingdan = new Dingdan();

                // 设置Id字段
                dingdan.setId(rs.getInt("id"));
                // 设置Bianhao字段
                dingdan.setBianhao(rs.getString("bianhao"));
                // 设置Shangpin字段
                dingdan.setShangpin(rs.getString("shangpin"));
                // 设置Zongjia字段
                dingdan.setZongjia(rs.getString("zongjia"));
                // 设置Peisongfei字段
                dingdan.setPeisongfei(rs.getString("peisongfei"));
                // 设置Youhui字段
                dingdan.setYouhui(rs.getString("youhui"));
                // 设置Dingdanzongjia字段
                dingdan.setDingdanzongjia(rs.getString("dingdanzongjia"));
                // 设置Dingdanriqi字段
                dingdan.setDingdanriqi(rs.getString("dingdanriqi"));
                // 设置Qiwangshijiian字段
                dingdan.setQiwangshijiian(rs.getString("qiwangshijiian"));
                // 设置Songdadidian字段
                dingdan.setSongdadidian(rs.getString("songdadidian"));
                dingdanall.add(dingdan);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dingdanall;
    }

    // 编写订单根据精准匹配查询方法
    public ArrayList<Dingdan> selectByprotyteEquals(Dingdan dingdanitem) {
        // TODO Auto-generated method stub
        sql = "select * from t_dingdan2 where 2 > 1 ";
        if (dingdanitem.getBianhao() != null && !"null".equals(dingdanitem.getBianhao())
                && !"".equals(dingdanitem.getBianhao())) {
            sql += " and bianhao = '" + dingdanitem.getBianhao() + "' ";
        }
        if (dingdanitem.getShangpin() != null && !"null".equals(dingdanitem.getShangpin())
                && !"".equals(dingdanitem.getShangpin())) {
            sql += " and shangpin = '" + dingdanitem.getShangpin() + "' ";
        }
        if (dingdanitem.getZongjia() != null && !"null".equals(dingdanitem.getZongjia())
                && !"".equals(dingdanitem.getZongjia())) {
            sql += " and zongjia = '" + dingdanitem.getZongjia() + "' ";
        }
        if (dingdanitem.getPeisongfei() != null && !"null".equals(dingdanitem.getPeisongfei())
                && !"".equals(dingdanitem.getPeisongfei())) {
            sql += " and peisongfei = '" + dingdanitem.getPeisongfei() + "' ";
        }
        if (dingdanitem.getYouhui() != null && !"null".equals(dingdanitem.getYouhui())
                && !"".equals(dingdanitem.getYouhui())) {
            sql += " and youhui = '" + dingdanitem.getYouhui() + "' ";
        }
        if (dingdanitem.getDingdanzongjia() != null && !"null".equals(dingdanitem.getDingdanzongjia())
                && !"".equals(dingdanitem.getDingdanzongjia())) {
            sql += " and dingdanzongjia = '" + dingdanitem.getDingdanzongjia() + "' ";
        }
        if (dingdanitem.getDingdanriqi() != null && !"null".equals(dingdanitem.getDingdanriqi())
                && !"".equals(dingdanitem.getDingdanriqi())) {
            sql += " and dingdanriqi = '" + dingdanitem.getDingdanriqi() + "' ";
        }
        if (dingdanitem.getQiwangshijiian() != null && !"null".equals(dingdanitem.getQiwangshijiian())
                && !"".equals(dingdanitem.getQiwangshijiian())) {
            sql += " and qiwangshijiian = '" + dingdanitem.getQiwangshijiian() + "' ";
        }
        if (dingdanitem.getSongdadidian() != null && !"null".equals(dingdanitem.getSongdadidian())
                && !"".equals(dingdanitem.getSongdadidian())) {
            sql += " and songdadidian = '" + dingdanitem.getSongdadidian() + "' ";
        }
        System.out.println(sql);
        ArrayList<Dingdan> dingdanall = new ArrayList<Dingdan>();

        try {
            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery();
            while (rs.next()) {
                Dingdan dingdan = new Dingdan();

                // 设置Id字段
                dingdan.setId(rs.getInt("id"));
                // 设置Bianhao字段
                dingdan.setBianhao(rs.getString("bianhao"));
                // 设置Shangpin字段
                dingdan.setShangpin(rs.getString("shangpin"));
                // 设置Zongjia字段
                dingdan.setZongjia(rs.getString("zongjia"));
                // 设置Peisongfei字段
                dingdan.setPeisongfei(rs.getString("peisongfei"));
                // 设置Youhui字段
                dingdan.setYouhui(rs.getString("youhui"));
                // 设置Dingdanzongjia字段
                dingdan.setDingdanzongjia(rs.getString("dingdanzongjia"));
                // 设置Dingdanriqi字段
                dingdan.setDingdanriqi(rs.getString("dingdanriqi"));
                // 设置Qiwangshijiian字段
                dingdan.setQiwangshijiian(rs.getString("qiwangshijiian"));
                // 设置Songdadidian字段
                dingdan.setSongdadidian(rs.getString("songdadidian"));
                dingdanall.add(dingdan);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dingdanall;
    }

    // 编写订单根据字段排序查询方法
    public ArrayList<Dingdan> selectByProtyteOrder(String protyte, String order, Integer num) {
        // TODO Auto-generated method stub
        sql = "select * from t_dingdan2 order by " + protyte + " ";

        if (order != null && !"null".equals(order) && !"".equals(order)) {
            sql += order;
        }

        System.out.println(sql);
        ArrayList<Dingdan> dingdanall = new ArrayList<Dingdan>();
        try {
            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery();
            while (rs.next()) {
                Dingdan dingdan = new Dingdan();

                // 设置Id字段
                dingdan.setId(rs.getInt("id"));
                // 设置Bianhao字段
                dingdan.setBianhao(rs.getString("bianhao"));
                // 设置Shangpin字段
                dingdan.setShangpin(rs.getString("shangpin"));
                // 设置Zongjia字段
                dingdan.setZongjia(rs.getString("zongjia"));
                // 设置Peisongfei字段
                dingdan.setPeisongfei(rs.getString("peisongfei"));
                // 设置Youhui字段
                dingdan.setYouhui(rs.getString("youhui"));
                // 设置Dingdanzongjia字段
                dingdan.setDingdanzongjia(rs.getString("dingdanzongjia"));
                // 设置Dingdanriqi字段
                dingdan.setDingdanriqi(rs.getString("dingdanriqi"));
                // 设置Qiwangshijiian字段
                dingdan.setQiwangshijiian(rs.getString("qiwangshijiian"));
                // 设置Songdadidian字段
                dingdan.setSongdadidian(rs.getString("songdadidian"));
                dingdanall.add(dingdan);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (num == null || "".equals(num)) {
            dingdanall = dingdanall;
        } else {
            if (num <= dingdanall.size()) {
                dingdanall = (ArrayList<Dingdan>) dingdanall.subList(0, num);
            }
        }

        return dingdanall;
    }
}
