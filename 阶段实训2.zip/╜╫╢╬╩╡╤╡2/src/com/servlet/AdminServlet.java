package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.UUID;
import java.util.List;
import com.dao.AdminDao;
import com.model.Admin;
import com.dao.AdminDao;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.servlet.http.HttpSession;
import com.connection.ConnectionManager;

/**
 * Servlet implementation class AdminServlet
 */
@MultipartConfig
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdminServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//
		// response.getWriter().append("Served at:
		// ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		// RequestDispatcher dispatcher =
		// request.getRequestDispatcher("/a.jsp");
		// dispatcher.forward(request, response);

		HttpSession session = request.getSession();

		response.setContentType("text/html;charset=UTF-8");
		String action = request.getParameter("action");

		// 以上为固定格式，请勿修改
		AdminDao adminDao = new AdminDao();

		// 根据页面传入的action判断，跳转到添加管理员页面
		if ("tianjiaadmin".equals(action)) {
			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/tianjiaadmin.jsp");
			dispatcher.forward(request, response);
			return;
		}

		// 根据页面传入的action判断，处理添加管理员方法
		if ("tianjiaadminact".equals(action)) {

			// 从request中获取管理员id信息
			String idstr = request.getParameter("id");
			Integer id = null;
			if (idstr != null && !"null".equals(idstr)) {

				// 将管理员id信息从字符串转换为数字
				id = Integer.parseInt(idstr);
			}
			// 从request中获取账号信息
			String username = request.getParameter("username");

			// 从request中获取密码信息
			String password = request.getParameter("password");
			Admin admin = new Admin();
			if (!"".equals(id) && id != null && !"null".equals(id)) {
				admin.setId(id);
			}
			if (!"".equals(username) && !"null".equals(username) && username != null) {
				admin.setUsername(username);
			} else {
				admin.setUsername("");
			}
			if (!"".equals(password) && !"null".equals(password) && password != null) {
				admin.setPassword(password);
			} else {
				admin.setPassword("");
			}

			adminDao.insert(admin);
			request.setAttribute("message", "添加管理员成功");

			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/AdminServlet?action=adminguanli");
			dispatcher.forward(request, response);
			return;
		}

		// 根据页面传入的action判断，跳转到管理员管理页面，并查询出所有管理员信息
		if ("adminguanli".equals(action)) {

			List<Admin> adminall = adminDao.selectAll();
			request.setAttribute("adminall", adminall);

			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/adminguanli.jsp");
			dispatcher.forward(request, response);
			return;
		}

		// 根据页面传入的action判断，跳转到管理员查看页面
		if ("adminchakan".equals(action)) {

			List<Admin> adminall = adminDao.selectAll();
			request.setAttribute("adminall", adminall);

			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/adminchakan.jsp");
			dispatcher.forward(request, response);
			return;
		}

		// 根据页面传入的action判断，跳转到管理员修改页面
		if ("xiugaiadmin".equals(action)) {

			Integer id = Integer.parseInt(request.getParameter("id"));

			Admin admin = adminDao.selectById(id);

			request.setAttribute("admin", admin);

			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/xiugaiadmin.jsp");
			dispatcher.forward(request, response);
			return;
		}

		// 根据页面传入的action判断，处理管理员修改操作
		if ("xiugaiadminact".equals(action)) {

			// 从request中获取管理员id信息
			String idstr = request.getParameter("id");
			Integer id = null;
			if (idstr != null && !"null".equals(idstr)) {

				// 将管理员id信息从字符串转换为数字
				id = Integer.parseInt(idstr);
			}
			// 从request中获取账号信息
			String username = request.getParameter("username");

			// 从request中获取密码信息
			String password = request.getParameter("password");

			Admin admin = new Admin();

			if (!"".equals(id) && id != null && !"null".equals(id)) {
				admin.setId(id);
			}
			if (!"".equals(username) && !"null".equals(username) && username != null) {
				admin.setUsername(username);
			} else {
				admin.setUsername("");
			}
			if (!"".equals(password) && !"null".equals(password) && password != null) {
				admin.setPassword(password);
			} else {
				admin.setPassword("");
			}

			adminDao.updateById(admin);
			request.setAttribute("message", "修改管理员成功");

			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/AdminServlet?action=adminguanli");
			dispatcher.forward(request, response);
			return;
		}

		// 根据页面传入的action判断，处理管理员删除操作
		if ("shanchuadmin".equals(action)) {

			Integer id = Integer.parseInt(request.getParameter("id"));

			adminDao.deleteById(id);

			request.setAttribute("message", "删除管理员成功");

			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/AdminServlet?action=adminguanli");
			dispatcher.forward(request, response);
			return;
		}

	}

	// 上传文件图片等
	public String uploadUtile(Part part, HttpServletRequest request) throws IOException {
		// 获取请求的信息
		String name = part.getHeader("content-disposition");
		if (name.lastIndexOf(".") < 0) {
			return null;
		}
		// System.out.println(name);//测试使用
		// System.out.println(desc);//

		// 获取上传文件的目录
		String root = request.getServletContext().getRealPath("/resource/uploads");
		System.out.println("上传文件的路径：" + root);

		// 获取文件的后缀
		String str = name.substring(name.lastIndexOf("."), name.length() - 1);
		System.out.println("获取文件的后缀：" + str);

		// 生成一个新的文件名，不重复，数据库存储的就是这个文件名，不重复的
		String fname = UUID.randomUUID().toString() + str;

		String filename = root + "\\" + fname;
		System.out.println("存放文件的地址：" + filename);

		// 上传文件到指定目录，不想上传文件就不调用这个
		part.write(filename);

		return fname;
	}

}
