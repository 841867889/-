package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.UUID;
import java.util.List;
import com.dao.DingdanDao3;
import com.model.Dingdan;
import com.dao.DingdanDao3;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.servlet.http.HttpSession;
import com.connection.ConnectionManager;

/**
 * Servlet implementation class DingdanServlet
 */
@MultipartConfig
@WebServlet("/DingdanServlet3")
public class DingdanServlet3 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DingdanServlet3() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        //
        // response.getWriter().append("Served at:
        // ").append(request.getContextPath());
        doPost(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        // doGet(request, response);
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        // RequestDispatcher dispatcher =
        // request.getRequestDispatcher("/a.jsp");
        // dispatcher.forward(request, response);

        HttpSession session = request.getSession();

        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");

        // 以上为固定格式，请勿修改
        DingdanDao3 dingdanDao = new DingdanDao3();

        // 根据页面传入的action判断，跳转到添加订单页面
        if ("tianjiadingdan".equals(action)) {
            // 定义返回地址
            String backurl = request.getParameter("backurl");

            // 如果页面传入的返回地址不为空，则返回页面传入的地址
            if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
                dispatcher.forward(request, response);
                return;
            }
            RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/tianjiadingdan3.jsp");
            dispatcher.forward(request, response);
            return;
        }

        // 根据页面传入的action判断，处理添加订单方法
        if ("tianjiadingdanact".equals(action)) {

            // 从request中获取订单id信息
            String idstr = request.getParameter("id");
            Integer id = null;
            if (idstr != null && !"null".equals(idstr)) {

                // 将订单id信息从字符串转换为数字
                id = Integer.parseInt(idstr);
            }
            // 从request中获取订单编号信息
            String bianhao = request.getParameter("bianhao");

            // 从request中获取订单商品信息
            String shangpin = request.getParameter("shangpin");

            // 从request中获取商品总价信息
            String zongjia = request.getParameter("zongjia");

            // 从request中获取配送费信息
            String peisongfei = request.getParameter("peisongfei");

            // 从request中获取会员优惠信息
            String youhui = request.getParameter("youhui");

            // 从request中获取订单总价信息
            String dingdanzongjia = request.getParameter("dingdanzongjia");

            // 从request中获取订单日期信息
            String dingdanriqi = request.getParameter("dingdanriqi");

            // 从request中获取订单期望送达时间信息
            String qiwangshijiian = request.getParameter("qiwangshijiian");

            // 从request中获取订单送达区域信息
            String songdadidian = request.getParameter("songdadidian");
            Dingdan dingdan = new Dingdan();
            if (!"".equals(id) && id != null && !"null".equals(id)) {
                dingdan.setId(id);
            }
            if (!"".equals(bianhao) && !"null".equals(bianhao) && bianhao != null) {
                dingdan.setBianhao(bianhao);
            } else {
                dingdan.setBianhao("");
            }
            if (!"".equals(shangpin) && !"null".equals(shangpin) && shangpin != null) {
                dingdan.setShangpin(shangpin);
            } else {
                dingdan.setShangpin("");
            }
            if (!"".equals(zongjia) && !"null".equals(zongjia) && zongjia != null) {
                dingdan.setZongjia(zongjia);
            } else {
                dingdan.setZongjia("");
            }
            if (!"".equals(peisongfei) && !"null".equals(peisongfei) && peisongfei != null) {
                dingdan.setPeisongfei(peisongfei);
            } else {
                dingdan.setPeisongfei("");
            }
            if (!"".equals(youhui) && !"null".equals(youhui) && youhui != null) {
                dingdan.setYouhui(youhui);
            } else {
                dingdan.setYouhui("");
            }
            if (!"".equals(dingdanzongjia) && !"null".equals(dingdanzongjia) && dingdanzongjia != null) {
                dingdan.setDingdanzongjia(dingdanzongjia);
            } else {
                dingdan.setDingdanzongjia("");
            }
            if (!"".equals(dingdanriqi) && !"null".equals(dingdanriqi) && dingdanriqi != null) {
                dingdan.setDingdanriqi(dingdanriqi);
            } else {
                dingdan.setDingdanriqi("");
            }
            if (!"".equals(qiwangshijiian) && !"null".equals(qiwangshijiian) && qiwangshijiian != null) {
                dingdan.setQiwangshijiian(qiwangshijiian);
            } else {
                dingdan.setQiwangshijiian("");
            }
            if (!"".equals(songdadidian) && !"null".equals(songdadidian) && songdadidian != null) {
                dingdan.setSongdadidian(songdadidian);
            } else {
                dingdan.setSongdadidian("");
            }

            dingdanDao.insert(dingdan);
            request.setAttribute("message", "添加报废成功");

            // 定义返回地址
            String backurl = request.getParameter("backurl");

            // 如果页面传入的返回地址不为空，则返回页面传入的地址
            if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
                dispatcher.forward(request, response);
                return;
            }
            RequestDispatcher dispatcher = request.getRequestDispatcher("/DingdanServlet3?action=dingdanguanli");
            dispatcher.forward(request, response);
            return;
        }

        // 根据页面传入的action判断，跳转到订单管理页面，并查询出所有订单信息
        if ("dingdanguanli".equals(action)) {

            String bianhao = request.getParameter("bianhao");
            String shangpin = request.getParameter("shangpin");
            String quyu = request.getParameter("quyu");

            Dingdan dingdanitem = new Dingdan();

            dingdanitem.setBianhao(bianhao);
            dingdanitem.setShangpin(shangpin);
            dingdanitem.setSongdadidian(quyu);

            List<Dingdan> dingdanall = dingdanDao.selectByprotyteLike(dingdanitem);
            request.setAttribute("dingdanall", dingdanall);

            // 定义返回地址
            String backurl = request.getParameter("backurl");

            // 如果页面传入的返回地址不为空，则返回页面传入的地址
            if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
                dispatcher.forward(request, response);
                return;
            }
            RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/dingdanguanli3.jsp");
            dispatcher.forward(request, response);
            return;
        }

        // 根据页面传入的action判断，跳转到订单查看页面
        if ("dingdanchakan".equals(action)) {

            List<Dingdan> dingdanall = dingdanDao.selectAll();
            request.setAttribute("dingdanall", dingdanall);

            // 定义返回地址
            String backurl = request.getParameter("backurl");

            // 如果页面传入的返回地址不为空，则返回页面传入的地址
            if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
                dispatcher.forward(request, response);
                return;
            }
            RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/dingdanchakan3.jsp");
            dispatcher.forward(request, response);
            return;
        }

        // 根据页面传入的action判断，跳转到订单修改页面
        if ("xiugaidingdan".equals(action)) {

            Integer id = Integer.parseInt(request.getParameter("id"));

            Dingdan dingdan = dingdanDao.selectById(id);

            request.setAttribute("dingdan", dingdan);

            // 定义返回地址
            String backurl = request.getParameter("backurl");

            // 如果页面传入的返回地址不为空，则返回页面传入的地址
            if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
                dispatcher.forward(request, response);
                return;
            }
            RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/xiugaidingdan3.jsp");
            dispatcher.forward(request, response);
            return;
        }

        // 根据页面传入的action判断，处理订单修改操作
        if ("xiugaidingdanact".equals(action)) {

            // 从request中获取订单id信息
            String idstr = request.getParameter("id");
            Integer id = null;
            if (idstr != null && !"null".equals(idstr)) {

                // 将订单id信息从字符串转换为数字
                id = Integer.parseInt(idstr);
            }
            // 从request中获取订单编号信息
            String bianhao = request.getParameter("bianhao");

            // 从request中获取订单商品信息
            String shangpin = request.getParameter("shangpin");

            // 从request中获取商品总价信息
            String zongjia = request.getParameter("zongjia");

            // 从request中获取配送费信息
            String peisongfei = request.getParameter("peisongfei");

            // 从request中获取会员优惠信息
            String youhui = request.getParameter("youhui");

            // 从request中获取订单总价信息
            String dingdanzongjia = request.getParameter("dingdanzongjia");

            // 从request中获取订单日期信息
            String dingdanriqi = request.getParameter("dingdanriqi");

            // 从request中获取订单期望送达时间信息
            String qiwangshijiian = request.getParameter("qiwangshijiian");

            // 从request中获取订单送达区域信息
            String songdadidian = request.getParameter("songdadidian");

            Dingdan dingdan = new Dingdan();

            if (!"".equals(id) && id != null && !"null".equals(id)) {
                dingdan.setId(id);
            }
            if (!"".equals(bianhao) && !"null".equals(bianhao) && bianhao != null) {
                dingdan.setBianhao(bianhao);
            } else {
                dingdan.setBianhao("");
            }
            if (!"".equals(shangpin) && !"null".equals(shangpin) && shangpin != null) {
                dingdan.setShangpin(shangpin);
            } else {
                dingdan.setShangpin("");
            }
            if (!"".equals(zongjia) && !"null".equals(zongjia) && zongjia != null) {
                dingdan.setZongjia(zongjia);
            } else {
                dingdan.setZongjia("");
            }
            if (!"".equals(peisongfei) && !"null".equals(peisongfei) && peisongfei != null) {
                dingdan.setPeisongfei(peisongfei);
            } else {
                dingdan.setPeisongfei("");
            }
            if (!"".equals(youhui) && !"null".equals(youhui) && youhui != null) {
                dingdan.setYouhui(youhui);
            } else {
                dingdan.setYouhui("");
            }
            if (!"".equals(dingdanzongjia) && !"null".equals(dingdanzongjia) && dingdanzongjia != null) {
                dingdan.setDingdanzongjia(dingdanzongjia);
            } else {
                dingdan.setDingdanzongjia("");
            }
            if (!"".equals(dingdanriqi) && !"null".equals(dingdanriqi) && dingdanriqi != null) {
                dingdan.setDingdanriqi(dingdanriqi);
            } else {
                dingdan.setDingdanriqi("");
            }
            if (!"".equals(qiwangshijiian) && !"null".equals(qiwangshijiian) && qiwangshijiian != null) {
                dingdan.setQiwangshijiian(qiwangshijiian);
            } else {
                dingdan.setQiwangshijiian("");
            }
            if (!"".equals(songdadidian) && !"null".equals(songdadidian) && songdadidian != null) {
                dingdan.setSongdadidian(songdadidian);
            } else {
                dingdan.setSongdadidian("");
            }

            dingdanDao.updateById(dingdan);
            request.setAttribute("message", "修改报废单成功");

            // 定义返回地址
            String backurl = request.getParameter("backurl");

            // 如果页面传入的返回地址不为空，则返回页面传入的地址
            if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
                dispatcher.forward(request, response);
                return;
            }
            RequestDispatcher dispatcher = request.getRequestDispatcher("/DingdanServlet3?action=dingdanguanli");
            dispatcher.forward(request, response);
            return;
        }

        // 根据页面传入的action判断，处理订单删除操作
        if ("shanchudingdan".equals(action)) {

            Integer id = Integer.parseInt(request.getParameter("id"));

            dingdanDao.deleteById(id);

            request.setAttribute("message", "删除报废成功");

            // 定义返回地址
            String backurl = request.getParameter("backurl");

            // 如果页面传入的返回地址不为空，则返回页面传入的地址
            if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
                RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
                dispatcher.forward(request, response);
                return;
            }
            RequestDispatcher dispatcher = request.getRequestDispatcher("/DingdanServlet3?action=dingdanguanli");
            dispatcher.forward(request, response);
            return;
        }

    }

    // 上传文件图片等
    public String uploadUtile(Part part, HttpServletRequest request) throws IOException {
        // 获取请求的信息
        String name = part.getHeader("content-disposition");
        if (name.lastIndexOf(".") < 0) {
            return null;
        }
        // System.out.println(name);//测试使用
        // System.out.println(desc);//

        // 获取上传文件的目录
        String root = request.getServletContext().getRealPath("/resource/uploads");
        System.out.println("上传文件的路径：" + root);

        // 获取文件的后缀
        String str = name.substring(name.lastIndexOf("."), name.length() - 1);
        System.out.println("获取文件的后缀：" + str);

        // 生成一个新的文件名，不重复，数据库存储的就是这个文件名，不重复的
        String fname = UUID.randomUUID().toString() + str;

        String filename = root + "\\" + fname;
        System.out.println("存放文件的地址：" + filename);

        // 上传文件到指定目录，不想上传文件就不调用这个
        part.write(filename);

        return fname;
    }

}
