package com.servlet;

import java.io.IOException;
import java.util.List;
import java.util.UUID;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import com.dao.AdminDao;
import com.model.Admin;

/**
 * Servlet implementation class LoginAndRegistServlet
 */
@MultipartConfig
@WebServlet("/LoginAndRegistServlet")
public class LoginAndRegistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginAndRegistServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//
		// response.getWriter().append("Served at:
		// ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);
		// RequestDispatcher dispatcher =
		// request.getRequestDispatcher("/a.jsp");
		// dispatcher.forward(request, response);
		HttpSession session = request.getSession();
		response.setContentType("text/html;charset=UTF-8");
		String action = request.getParameter("action");
		// 以上为固定格式，请勿修改

		AdminDao adminDao = new AdminDao();

		if ("login".equals(action)) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/login.jsp");
			dispatcher.forward(request, response);
			return;
		}

		if ("regist".equals(action)) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/regist.jsp");
			dispatcher.forward(request, response);
			return;
		}

		if ("loginact".equals(action)) {

			String shenfen = request.getParameter("shenfen"); // 管理员登录处理开始
			if ("管理员".equals(shenfen)) {

				String username = request.getParameter("username");
				String password = request.getParameter("password");

				Admin admin = new Admin();

				admin.setUsername(username);
				admin.setPassword(password);

				List<Admin> admins = adminDao.selectByprotyteEquals(admin);

				// 如果结果为空
				if (admins.isEmpty()) {

					// 将账户或密码错误保存到request中

					request.setAttribute("message", "账号或密码错误");

					// 定义返回地址
					String backurl = request.getParameter("backurl");

					// 如果页面传入的返回地址不为空，则返回页面传入的地址
					if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
						RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
						dispatcher.forward(request, response);
						return;
					}
					RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/login.jsp");
					dispatcher.forward(request, response);
					return;

				} else {

					// 登录成功，将名字保存到session中

					session.setAttribute("mingzi", admins.get(0).getUsername());

					// 登录成功，将登录用户id保存到session中

					session.setAttribute("id", admins.get(0).getId());

					// 登录成功，将登录用户保存到session中

					session.setAttribute("userinfo", admins.get(0));

					// 登录成功，将登录用户身份保存到session中

					session.setAttribute("shenfen", shenfen);

					// 定义返回地址
					String backurl = request.getParameter("backurl");

					// 如果页面传入的返回地址不为空，则返回页面传入的地址
					if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
						RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
						dispatcher.forward(request, response);
						return;
					}
					RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/adminindex.jsp");
					dispatcher.forward(request, response);
					return;

				}
			}
			// 管理员登录处理结束
			// 将请选择登录身份保存到request的message中

			request.setAttribute("message", "请选择登录身份");

			// 返回到登录页

			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/login.jsp");
			dispatcher.forward(request, response);
			return;
		}

		if ("registact".equals(action)) {

			String shenfen = request.getParameter("shenfen");
			if ("管理员".equals(shenfen)) {

				String username = request.getParameter("username");
				String password = request.getParameter("password");

				Admin admin = new Admin();
				admin.setUsername(username);

				List<Admin> admins = adminDao.selectByprotyteEquals(admin);
				admin.setPassword(password);
				if (admins.isEmpty()) {
					adminDao.insert(admin);
					request.setAttribute("message", "注册成功，请登录");
					// 定义返回地址
					String backurl = request.getParameter("backurl");

					// 如果页面传入的返回地址不为空，则返回页面传入的地址
					if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
						RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
						dispatcher.forward(request, response);
						return;
					}
					RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/login.jsp");
					dispatcher.forward(request, response);
					return;
				} else {
					request.setAttribute("message", "该账号已存在，请重新注册");
					// 定义返回地址
					String backurl = request.getParameter("backurl");

					// 如果页面传入的返回地址不为空，则返回页面传入的地址
					if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
						RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
						dispatcher.forward(request, response);
						return;
					}
					RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/regist.jsp");
					dispatcher.forward(request, response);
					return;
				}
			} // 将请选择注册身份保存到request的message中

			request.setAttribute("message", "请选择注册身份");

			// 返回到注册页

			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/regist.jsp");
			dispatcher.forward(request, response);
			return;
		}

		if ("tuichuxitong".equals(action)) {

			session.invalidate();

			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/login.jsp");
			dispatcher.forward(request, response);
			return;
		}

		if ("adminindex".equals(action)) {
			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/adminindex.jsp");
			dispatcher.forward(request, response);
			return;
		}
		if ("adminxiugaigerenxinxiact".equals(action)) {

			String idstr = request.getParameter("id");
			Integer id = null;
			if (idstr != null && !"null".equals(idstr)) {
				id = Integer.parseInt(idstr);
			}
			String username = request.getParameter("username");
			String password = request.getParameter("password");

			Admin admin = adminDao.selectById(id);

			if (!"".equals(id) && id != null && !"null".equals(id)) {
				admin.setId(id);
			}
			if (!"".equals(username) && username != null && !"null".equals(username)) {
				admin.setUsername(username);
			} else {
				admin.setUsername("");
			}
			if (!"".equals(password) && password != null && !"null".equals(password)) {
				admin.setPassword(password);
			} else {
				admin.setPassword("");
			}

			adminDao.updateById(admin);

			// 将老师信息同步到session中
			session.setAttribute("userinfo", admin);

			// 给出页面提示信息修改信息成功
			request.setAttribute("message", "管理员修改个人信息成功");

			// 定义返回地址
			String backurl = request.getParameter("backurl");

			// 如果页面传入的返回地址不为空，则返回页面传入的地址
			if (backurl != null && !"null".equals(backurl) && !"".equals(backurl)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher(backurl);
				dispatcher.forward(request, response);
				return;
			}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/adminindex.jsp");
			dispatcher.forward(request, response);
			return;
		}

	}

	// 上传文件图片等
	public String uploadUtile(Part part, HttpServletRequest request) throws IOException {
		// 获取请求的信息
		String name = part.getHeader("content-disposition");
		if (name.lastIndexOf(".") < 0) {
			return null;
		}
		// System.out.println(name);//测试使用
		// System.out.println(desc);//
		// 获取上传文件的目录
		String root = request.getServletContext().getRealPath("/resource/uploads");
		System.out.println("上传文件的路径：" + root);
		// 获取文件的后缀
		String str = name.substring(name.lastIndexOf("."), name.length() - 1);
		System.out.println("获取文件的后缀：" + str);
		// 生成一个新的文件名，不重复，数据库存储的就是这个文件名，不重复的
		String fname = UUID.randomUUID().toString() + str;
		String filename = root + "\\" + fname;
		System.out.println("存放文件的地址：" + filename);
		// 上传文件到指定目录，不想上传文件就不调用这个
		part.write(filename);
		return fname;
	}
}
