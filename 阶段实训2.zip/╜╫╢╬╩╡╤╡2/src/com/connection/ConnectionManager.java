package com.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
	private String driver;
	private String url;
	private String userName;
	private String pwd;
	private Connection con;

	public ConnectionManager() {
		super();
		// TODO Auto-generated constructor stub
		// driver = "org.sqlite.JDBC";
		// url="jdbc:sqlite:"+System.getProperty("user.dir")+"\\database\\dingdanshuju.sqlite";
		// driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
		// url="jdbc:sqlserver://localhost:1433;databaseName=dingdanshuju";
		driver = "com.mysql.jdbc.Driver";
		url = "jdbc:mysql://localhost:3306/dingdanshuju?useUnicode=true&characterEncoding=UTF-8";
		userName = "root";
		pwd = "123456";
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public Connection getConnection() {
		try {
			con = DriverManager.getConnection(url, userName, pwd);
			// con = DriverManager.getConnection(url);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

	public void close() {
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
